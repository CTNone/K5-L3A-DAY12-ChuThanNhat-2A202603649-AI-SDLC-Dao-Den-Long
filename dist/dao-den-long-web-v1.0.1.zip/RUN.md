# Dao Den Long - web build

1. Extract this zip to any folder.
2. Run `python serve_web.py` (Python 3.10+).
3. Open the URL printed by the server, usually http://127.0.0.1:8060/.

The server sets the COOP/COEP headers that the Godot web build needs.
Use `--port` or `--no-browser` if needed.
